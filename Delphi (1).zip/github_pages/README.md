# Instrumento Delphi TEA-UNA / SELMA-B
## Doctorado en Ciencias Jurídicas — Selma Bogado — UNA

### Antes de publicar
1. Abra index.html con un editor de texto
2. Busque FORMSPREE_URL y reemplace con su URL de Formspree (formspree.io)
3. Opcional: cambie ADMIN_PASS y API_KEY

### Publicar en GitHub Pages
1. Suba ambos archivos a un repositorio público en GitHub
2. Vaya a Settings > Pages > Source: main / root
3. Su URL: https://su-usuario.github.io/nombre-repo/

### Archivos
- index.html — El instrumento completo (8 secciones)
- qr.html — Página QR para imprimir y distribuir a panelistas
